export default {
    plugins: {

    },
};
