import { createApp } from 'vue';
import router from './router';
import App from './App.vue';
import axios from 'axios';
import { currencySymbols, getCurrencySymbol } from './utils/currencySymbols';


const token = localStorage.getItem('token');
if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

const app = createApp(App);

app.config.globalProperties.$currencySymbols = currencySymbols;
app.config.globalProperties.$getCurrencySymbol = getCurrencySymbol;

app.use(router);
app.mount('#app');
