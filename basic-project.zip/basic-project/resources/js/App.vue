<template>
    <div id="app">
        <!-- Global container for your layout -->
        <div v-if="isAuthenticated">
            <!-- Conditionally show layout if user is authenticated -->
            <router-view></router-view>  <!-- Render the current route component (like Dashboard, etc.) -->
        </div>

        <div v-else>
            <!-- If not authenticated, show login or register routes -->
            <router-view></router-view>
        </div>
    </div>
</template>

<script>

    export default {
        name: 'App',
        data() {
            return {
                isAuthenticated: false,
            };
        },
        created() {
            this.isAuthenticated = localStorage.getItem('token') ? true : false;
            feather.replace({ 'aria-hidden': 'true' });
        },
        watch: {
            isAuthenticated(newVal) {
                if (!newVal) {
                    this.$router.push({ name: 'login' });
                }
            }
        }
    }
</script>

<style>
</style>
