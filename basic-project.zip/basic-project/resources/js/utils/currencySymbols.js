export const currencySymbols = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    INR: "₹",
    JPY: "¥",
    AUD: "A$",
    CAD: "C$",
};

export function getCurrencySymbol(currencyCode) {
    return currencySymbols[currencyCode] || currencyCode;
}
