<template>
    <div class="filter-section">
        <div class="d-flex flex-wrap">
            <div
                v-for="(option, index) in filterOptions"
                :key="index"
                class="filter-option"
                :class="{ 'selected': selectedOptions.includes(option.label) }"
                @click="toggleOption(option.label)"
            >
                <div class="icon-container">
                    <img src="/images/wedding-ring.svg" class="img-responsive">
                </div>
                <div class="label-container">
                    <span class="label">{{ option.label }}</span>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        data() {
            return {
                filterOptions: [
                    { label: "Engagement Rings", icon: "bi bi-gem" },
                    { label: "Wedding Bands", icon: "bi bi-ring" },
                    { label: "Fashion Women", icon: "bi bi-person" },
                    { label: "Fashion Men", icon: "bi bi-person-circle" },
                    { label: "Earrings", icon: "bi bi-ear" },
                    { label: "Bracelets", icon: "bi bi-circle" },
                    { label: "Necklaces", icon: "bi bi-diamond" },
                    { label: "Pearl Jewelry", icon: "bi bi-droplet" },
                    { label: "Watches", icon: "bi bi-watch" },
                    { label: "Accessories", icon: "bi bi-crown" },
                ],
                selectedOptions: [],
            };
        },
        methods: {
            toggleOption(option) {
                if (this.selectedOptions.includes(option)) {
                    this.selectedOptions = this.selectedOptions.filter((item) => item !== option);
                } else {
                    this.selectedOptions.push(option);
                }
            },
        },
    };
</script>

<style scoped>
    .filter-section {
        background-color: #e8f5f5;
        border: 1px solid #b2d8d8;
        border-radius: 8px;
        padding: 1rem;
    }

    .filter-option {
        width: 100px;
        height: 120px;
        margin: 0.5rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border: 1px solid #ccc;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s;
        background-color: #fff;
    }

    .filter-option:hover {
        background-color: #f0f8f8;
    }

    .filter-option.selected {
        background-color: #5bc8c8;
        color: #fff;
    }

    .icon-container {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 50%;
    }

    .icon-container img {
        height: 50px;
        object-fit: contain;
    }

    .label-container {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        font-size: 0.9rem;
        font-weight: bold;
        height: 50%;
    }

</style>
