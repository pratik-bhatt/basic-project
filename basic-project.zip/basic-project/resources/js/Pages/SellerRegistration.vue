<template>
    <div>
        <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
            <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/">DNA Carbon LLP</a>
        </header>

        <div class="container mt-5">
            <div class="row justify-content-center">
                <main class="col-md-6">
                    <div class="card shadow-sm border-0 rounded-lg p-4">
                        <div class="card-body" v-if="registrationStatus">
                            <div class="alert alert-success mt-3" role="alert">
                                Thank you for filling all details. Out team will notify you when your account is ready to use.
                                <hr>
                                Visit <a class="" href="/">Login Page</a>.
                            </div>
                        </div>
                        <div class="card-body" v-else>
                            <h2 class="text-center mb-4 font-weight-bold">New Partner Registration</h2>

                            <!-- Seller Registration Form -->
                            <form @submit.prevent="registerSeller">
                                <!-- Name -->
                                <div class="form-group mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input
                                        id="name"
                                        type="text"
                                        class="form-control form-control-lg"
                                        v-model="name"
                                        placeholder="Enter your name"
                                        required
                                    />
                                </div>

                                <!-- Email -->
                                <div class="form-group mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input
                                        id="email"
                                        type="email"
                                        class="form-control form-control-lg"
                                        v-model="email"
                                        placeholder="Enter your email"
                                        required
                                    />
                                </div>

                                <!-- Password -->
                                <div class="form-group mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input
                                        id="password"
                                        type="password"
                                        class="form-control form-control-lg"
                                        v-model="password"
                                        placeholder="Enter your password"
                                        required
                                    />
                                </div>

                                <!-- Phone -->
                                <div class="form-group mb-3">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input
                                        id="phone"
                                        type="text"
                                        class="form-control form-control-lg"
                                        v-model="phone"
                                        placeholder="Enter your phone number"
                                        required
                                    />
                                </div>

                                <!-- Address -->
                                <div class="form-group mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <textarea
                                        id="address"
                                        class="form-control form-control-lg"
                                        v-model="address"
                                        placeholder="Enter your address"
                                        rows="2"
                                        required
                                    ></textarea>
                                </div>

                                <!-- Company Name -->
                                <div class="form-group mb-3">
                                    <label for="company_name" class="form-label">Company Name</label>
                                    <input
                                        id="company_name"
                                        type="text"
                                        class="form-control form-control-lg"
                                        v-model="companyName"
                                        placeholder="Enter your company name"
                                        required
                                    />
                                </div>

                                <!-- Domain -->
                                <div class="form-group mb-3">
                                    <label for="domain" class="form-label">Domain (if any)</label>
                                    <input
                                        id="domain"
                                        type="text"
                                        class="form-control form-control-lg"
                                        v-model="domain"
                                        placeholder="Enter your domain (optional)"
                                    />
                                </div>

                                <!-- Company Address -->
                                <div class="form-group mb-3">
                                    <label for="company_address" class="form-label">Company Address</label>
                                    <textarea
                                        id="company_address"
                                        class="form-control form-control-lg"
                                        v-model="companyAddress"
                                        placeholder="Enter your company address"
                                        rows="2"
                                    ></textarea>
                                </div>

                                <!-- Error Message -->
                                <div v-if="errorMessage" class="alert alert-danger mt-3">
                                    {{ errorMessage }}
                                </div>

                                <div class="form-group mt-4">
                                    <button
                                        type="submit"
                                        class="btn btn-shopify btn-block btn-lg d-flex justify-content-center align-items-center"
                                        :disabled="loading"
                                    >
                                        <span v-if="loading" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                        <span v-if="!loading">Register</span>
                                        <span v-else>Processing...</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from "axios";

    export default {
        name: "SellerRegistration",
        data() {
            return {
                loading: false,
                name: "",
                email: "",
                password: "",
                phone: "",
                address: "",
                companyName: "",
                domain: "",
                companyAddress: "",
                errorMessage: "",
                registrationStatus: false,
            };
        },
        methods: {
            async registerSeller() {
                try {
                    this.loading = true;
                    // Make a POST request to the backend
                    await axios.post("/api/register-seller", {
                        name: this.name,
                        email: this.email,
                        password: this.password,
                        phone: this.phone,
                        address: this.address,
                        company_name: this.companyName,
                        domain: this.domain,
                        company_address: this.companyAddress,
                    });
                    this.registrationStatus = true;
                } catch (error) {
                    this.errorMessage =
                        error.response?.data?.message || "Failed to register. Please try again.";
                } finally {
                    this.loading = false;
                }
            },
        },
    };
</script>

<style scoped>
    /* Styling similar to the previous version */
    body {
        background-color: #f6f9fc;
    }

    .navbar {
        z-index: 999;
        background-color: #343a40;
    }

    .card {
        border-radius: 16px;
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: none;
    }

    .card-body {
        padding: 30px;
    }

    h2 {
        font-size: 1.75rem;
        font-weight: 600;
        color: #333;
    }

    .form-control {
        border-radius: 8px;
        border: 1px solid #d1d8e0;
        padding: 12px;
        font-size: 1.1rem;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
    }

    .btn-shopify {
        background-color: #95bf47;
        border-color: #95bf47;
        font-size: 1.1rem;
        font-weight: 500;
        padding: 14px;
        border-radius: 8px;
        transition: all 0.2s ease-in-out;
    }

    .btn-shopify:hover {
        background-color: #74a93c;
        border-color: #74a93c;
    }

    .alert-danger {
        font-size: 0.875rem;
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }

    @media (max-width: 768px) {
        .card {
            margin: 20px;
        }
    }
</style>
