<template>
    <div>
        <!-- Header Section -->
        <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow ">
            <router-link to="/dashboard" class="navbar-brand me-0 px-3 header-logo-width ">
                DNA Carbon LLP
            </router-link>
            <button
                class="navbar-toggler position-absolute d-md-none collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#sidebarMenu"
                aria-controls="sidebarMenu"
                aria-expanded="false"
                aria-label="Toggle navigation"
                @click="toggleSidebar"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
<!--            <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">-->
            <div class="navbar-nav ms-auto">
                <!-- Dropdown -->
                <div class="nav-item dropdown position-relative">
                    <button
                        class="btn nav-link dropdown-toggle px-3"
                        id="userDropdown"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        style="min-width: 150px;"
                    >
                        Hello {{ user.name }}
                    </button>
                    <ul
                        class="dropdown-menu dropdown-menu-end position-absolute w-100"
                        aria-labelledby="userDropdown"
                        style="top: 100%; right: 0;"
                    >
                        <li><button class="dropdown-item" @click="logout">Sign out</button></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="container-fluid">
            <div class="row">
                <nav
                    id="sidebarMenu"
                    class="sidebar-width d-md-block bg-light sidebar collapse"
                    :class="{ show: sidebarOpen }"
                >
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <router-link
                                    :to="{ name: user.role === 'admin' ? 'adminHome' : 'sellerHome' }"
                                    class="nav-link"
                                    :class="{ active: $route.name === (user.role === 'admin' ? 'adminHome' : 'sellerHome') }"
                                >
                                    <span data-feather="home"></span>
                                    Dashboard
                                </router-link>
                            </li>
                            <li class="nav-item">
                                <router-link
                                    class="nav-link"
                                    to="/products"
                                    :class="{ active: $route.name === 'products'  || $route.name === 'productDetail' }"
                                >
                                    <span data-feather="shopping-cart"></span>
                                    Products
                                </router-link>
                            </li>
                            <li class="nav-item" v-if="user.role === 'admin'">
                                <router-link
                                    class="nav-link"
                                    to="/orders"
                                    :class="{ active: $route.name === 'orders' || $route.name === 'orderDetail' }"
                                >
                                    <span data-feather="file"></span>
                                    Orders
                                </router-link>
                            </li>
                            <li class="nav-item" v-if="user.role === 'admin'">
                                <router-link
                                    class="nav-link"
                                    to="/sellers"
                                    :class="{ active: $route.name === 'sellers' || $route.name === 'sellerDetail' }"
                                >
                                    <span data-feather="users"></span>
                                    Sellers
                                </router-link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <main class="col-md-10 ms-sm-auto col-lg-11 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <router-view></router-view>
            </div>
        </main>
    </div>
</template>

<script>
    import axios from 'axios';
    import feather from 'feather-icons';

    export default {
        data() {
            return {
                user: JSON.parse(localStorage.getItem('user')) || {},
                sidebarOpen: false, // Tracks the sidebar state
            };
        },
        mounted() {
            feather.replace({ 'aria-hidden': 'true' });
            if (this.$route.name === 'dashboard') {
                if (this.user.role === 'seller')
                    this.$router.push({ name: 'sellerHome' });
                else
                    this.$router.push({ name: 'adminHome' });
            }
        },
        watch: {
            $route() {
                this.sidebarOpen = false;
            },
        },
        methods: {
            toggleSidebar() {
                this.sidebarOpen = !this.sidebarOpen;
            },
            async logout() {
                try {
                    await axios.post("/api/logout", {}, {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`
                        }
                    });

                    // Clear local storage
                    localStorage.removeItem("token");
                    localStorage.removeItem("user");

                    this.$router.push({ name: "login" });
                } catch (error) {
                    alert("Failed to log out. Please try refreshing page.");
                }
            },
        },
    };
</script>

<style scoped>
    header {
        background-color: #f8f9fa;
        padding: 1rem;
        border-bottom: 1px solid #ddd;
    }

    nav ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        display: flex;
    }

    nav ul li {
        margin-right: 1rem;
    }

    nav ul li a {
        text-decoration: none;
        color: #007bff;
        font-size: 17px;
    }

    nav ul li a:hover {
        text-decoration: underline;
    }
</style>
