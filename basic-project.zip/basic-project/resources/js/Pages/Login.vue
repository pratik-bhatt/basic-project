<template>
    <div>
        <!-- Header Section -->
        <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
            <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/">DNA Carbon LLP</a>
        </header>

        <!-- Main Content Area -->
        <div class="container-fluid">
            <div class="row justify-content-center">
                <main class="col-md-6 col-lg-4 mt-5">
                    <div class="card shadow-sm border-0 rounded-lg p-4">
                        <div class="card-body" v-if="message">
                            <div class="alert alert-success mt-3" role="alert">
                                {{ message }}
                            </div>
                        </div>
                        <div class="card-body" v-else>
                            <h2 class="text-center mb-4 font-weight-bold">Sign In</h2>
                            <form @submit.prevent="loginUser">
                                <!-- Email Input -->
                                <div class="form-group mb-4">
                                    <label for="email" class="form-label">E-Mail Address</label>
                                    <input
                                        id="email"
                                        type="email"
                                        class="form-control form-control-lg"
                                        name="email"
                                        v-model="email"
                                        placeholder="Enter your email"
                                        required
                                    />
                                </div>

                                <!-- Password Input -->
                                <div class="form-group mb-4">
                                    <label for="password" class="form-label">Password</label>
                                    <input
                                        id="password"
                                        type="password"
                                        class="form-control form-control-lg"
                                        name="password"
                                        v-model="password"
                                        placeholder="Enter your password"
                                        required
                                    />
                                </div>

                                <!-- Error Message -->
                                <div v-if="errorMessage" class="alert alert-danger mt-3">
                                    {{ errorMessage }}
                                </div>

                                <div class="form-group mt-4">
                                    <button
                                        type="submit"
                                        class="btn btn-shopify btn-block btn-lg d-flex justify-content-center align-items-center"
                                        :disabled="loading"
                                    >
                                        <span v-if="loading" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                        <span v-if="!loading">Login</span>
                                        <span v-else>Logging in...</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from 'axios';

    export default {
        data() {
            return {
                email: '',
                password: '',
                errorMessage: '',
                loading: false,
                message: '',
            };
        },
        methods: {
            async loginUser() {
                // Validate inputs
                if (!this.email || !this.password) {
                    this.errorMessage = "Please fill in all fields.";
                    return;
                }

                try {
                    this.loading = true;

                    const response = await axios.post("/api/login", {
                        email: this.email,
                        password: this.password,
                    });

                    // Save user and token securely
                    const {user, token, role} = response.data;
                    localStorage.setItem("user", JSON.stringify(user));
                    localStorage.setItem("token", token);
                    localStorage.setItem("role", role);

                    // Redirect to the dashboard
                    if (role === 'seller')
                        this.$router.push({name: 'sellerHome'});
                    else
                        this.$router.push({name: 'adminHome'});
                } catch (error) {
                    if (error.response && error.response.status === 401) {
                        this.errorMessage = "Invalid email or password.";
                    } else if (error.response && error.response.status >= 500) {
                        this.errorMessage = "Server error. Please try again later.";
                    } else if (error.message) {
                        this.errorMessage = error.response.data.message;
                    } else {
                        this.errorMessage = "An error occurred. Please check your connection.";
                    }
                } finally {
                    this.loading = false;
                }
            },
        },
    };
</script>

<style scoped>
    /* General Body */
    body {
        background-color: #f6f9fc;
    }

    /* Header */
    .navbar {
        z-index: 999;
        background-color: #343a40;
    }

    /* Card */
    .card {
        border-radius: 16px;
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: none;
    }

    /* Card Body */
    .card-body {
        padding: 30px;
    }

    /* Title */
    h2 {
        font-size: 1.75rem;
        font-weight: 600;
        color: #333;
    }

    /* Form */
    .form-control {
        border-radius: 8px;
        border: 1px solid #d1d8e0;
        padding: 12px;
        font-size: 1.1rem;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
    }

    /* Button */
    .btn-shopify {
        background-color: #95bf47;
        border-color: #95bf47;
        font-size: 1.1rem;
        font-weight: 500;
        padding: 14px;
        border-radius: 8px;
        transition: all 0.2s ease-in-out;
    }

    .btn-shopify:hover {
        background-color: #74a93c;
        border-color: #74a93c;
    }

    /* Error Message */
    .alert-danger {
        font-size: 0.875rem;
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .card {
            margin: 20px;
        }
    }
</style>
