<template>
    <div class="container mt-5">
        <!-- Key Metrics -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3" v-for="metric in keyMetrics" :key="metric.label">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">{{ metric.label }}</h5>
                        <h3 class="display-5 text-primary">{{ metric.value }}</h3>
                        <p class="text-muted">{{ metric.description }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Graphs and Charts -->
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-light">Revenue Trends</div>
                    <div class="card-body">
                        <canvas id="revenueTrends"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-light">Order Trends</div>
                    <div class="card-body">
                        <canvas id="orderTrends"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-light">Top Performing Sellers</div>
                    <div class="card-body">
                        <canvas id="topSellers"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-light">Product Popularity</div>
                    <div class="card-body">
                        <canvas id="productPopularity"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Seller Reports -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-light">Seller Reports</div>
            <div class="card-body">
                <p><strong>Active Sellers:</strong> {{ sellerReports.activeSellers }}</p>
                <p><strong>Top Sellers:</strong> {{ sellerReports.topSellers }}</p>
                <p><strong>Inactive Sellers:</strong> {{ sellerReports.inactiveSellers }}</p>
            </div>
        </div>

        <!-- Product Reports -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-light">Product Reports</div>
            <div class="card-body">
                <p><strong>Best-Selling Products:</strong> {{ productReports.bestSellingProducts }}</p>
                <p><strong>Low-Stock Products:</strong> {{ productReports.lowStockProducts }}</p>
                <p><strong>Products Not Selected by Sellers:</strong> {{ productReports.unselectedProducts }}</p>
            </div>
        </div>


        <!-- Commission Reports -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-light">Commission Reports</div>
            <div class="card-body">
                <p><strong>Total Commission Given:</strong> {{ commissionReports.totalCommission }}</p>
                <p><strong>Seller-Wise Commission:</strong> {{ commissionReports.sellerCommission }}</p>
                <p><strong>Monthly Commission:</strong> {{ commissionReports.monthlyCommission }}</p>
            </div>
        </div>

        <!-- Notifications -->
        <div class="card shadow-sm">
            <div class="card-header bg-light">Notifications</div>
            <div class="card-body">
                <ul class="list-group">
                    <li class="list-group-item" v-for="alert in notifications" :key="alert">{{ alert }}</li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from 'axios';
    import { Chart } from "chart.js/auto";

    export default {
        name: "AdminHome",
        data() {
            return {
                loading: false,
                keyMetrics: [
                    { label: "Total Sellers", value: 120, description: "Active sellers on the platform" },
                    { label: "Total Products", value: 4500, description: "Products listed by all sellers" },
                    { label: "Total Orders", value: 15000, description: "Orders placed across all stores" },
                    { label: "Pending Orders", value: 200, description: "Orders yet to be fulfilled" },
                    { label: "Total Revenue", value: "$250,000", description: "Revenue generated from sales" },
                    { label: "New Sellers This Month", value: 10, description: "Recently joined sellers" },
                ],
                sellerReports: {
                    activeSellers: 100,
                    topSellers: 10,
                    inactiveSellers: 20,
                },
                productReports: {
                    bestSellingProducts: 50,
                    lowStockProducts: 25,
                    unselectedProducts: 30,
                },
                orderReports: {
                    fulfilledOrders: 14500,
                    orderSources: "Top sellers",
                    delayedOrders: 100,
                },
                commissionReports: {
                    totalCommission: "$50,000",
                    sellerCommission: "Seller-wise breakdown",
                    monthlyCommission: "$5,000",
                },
                activityLogs: [
                    "Seller John updated his store.",
                    "New order created.",
                    "Seller Alice joined the platform.",
                ],
                notifications: [
                    "5 new sellers awaiting approval.",
                    "200 pending orders to review.",
                    "10 sellers with no recent activity.",
                ],
            };
        },
        mounted() {
            axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
            if (JSON.parse(localStorage.getItem('user'))?.role === 'seller')
                this.$router.push({ name: 'sellerHome' });

            this.loadCharts();
        },
        methods: {
            loadCharts() {
                // Revenue Trends Line Chart
                const ctxRevenue = document.getElementById("revenueTrends").getContext("2d");
                new Chart(ctxRevenue, {
                    type: "line",
                    data: {
                        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                        datasets: [
                            {
                                label: "Revenue",
                                data: [5000, 10000, 15000, 20000, 25000, 30000],
                                borderColor: "#008060",
                                backgroundColor: "rgba(0, 128, 96, 0.2)",
                                borderWidth: 2,
                            },
                        ],
                    },
                });

                // Order Trends Bar Chart
                const ctxOrders = document.getElementById("orderTrends").getContext("2d");
                new Chart(ctxOrders, {
                    type: "bar",
                    data: {
                        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                        datasets: [
                            {
                                label: "Orders",
                                data: [500, 1000, 750, 1250, 1500, 2000],
                                backgroundColor: "#f39c12",
                            },
                        ],
                    },
                });

                // Top Sellers Pie Chart
                const ctxTopSellers = document.getElementById("topSellers").getContext("2d");
                new Chart(ctxTopSellers, {
                    type: "pie",
                    data: {
                        labels: ["Seller A", "Seller B", "Seller C", "Seller D"],
                        datasets: [
                            {
                                data: [30, 20, 25, 25],
                                backgroundColor: ["#f39c12", "#1abc9c", "#e74c3c", "#9b59b6"],
                            },
                        ],
                    },
                });

                // Product Popularity Bar Chart
                const ctxProductPopularity = document.getElementById("productPopularity").getContext("2d");
                new Chart(ctxProductPopularity, {
                    type: "bar",
                    data: {
                        labels: ["Product A", "Product B", "Product C", "Product D"],
                        datasets: [
                            {
                                label: "Sales",
                                data: [400, 300, 200, 100],
                                backgroundColor: "#3498db",
                            },
                        ],
                    },
                });
            },
        },
    }
</script>

<style scoped>
    .card {
        border-radius: 10px;
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
    }
    .card-header {
        font-size: 1.2rem;
        font-weight: 600;
        color: #333;
    }
    .text-primary {
        color: #008060 !important;
    }
</style>
