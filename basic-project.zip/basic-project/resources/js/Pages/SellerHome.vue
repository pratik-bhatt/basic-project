<template>
    <div class="container seller-dashboard">
        <div class="row py-4">
            <div class="col-12">
                <h1 class="dashboard-title">Seller Dashboard</h1>
                <p class="text-muted">Welcome back! Here are your latest store insights.</p>
            </div>
        </div>

        <!-- KPI Cards -->
        <div class="row my-4">
            <div
                class="col-lg-3 col-md-6 mb-3"
                v-for="(kpi, index) in kpis"
                :key="index"
            >
                <div class="card kpi-card">
                    <div class="card-body">
                        <h6 class="card-subtitle text-muted">{{ kpi.label }}</h6>
                        <h4 class="kpi-value">{{ kpi.value }}</h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row mb-4">
            <div class="col-lg-6 col-md-12 mb-4">
                <div class="card chart-card">
                    <div class="card-body">
                        <h5 class="card-title">Revenue Trends</h5>
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 mb-4">
                <div class="card chart-card">
                    <div class="card-body">
                        <h5 class="card-title">Order Trends</h5>
                        <canvas id="orderChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="row">
            <div class="col-md-12">
                <div class="card recent-orders-card">
                    <div class="card-body">
                        <h5 class="card-title">Recent Orders</h5>
                        <div v-if="recentOrders.length > 0">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Product</th>
                                    <th>Order Total</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(order, index) in recentOrders" :key="index">
                                    <td>{{ order.customer }}</td>
                                    <td>{{ order.product }}</td>
                                    <td>${{ order.total }}</td>
                                    <td>
                      <span
                          class="badge"
                          :class="getStatusBadge(order.status)"
                      >
                        {{ order.status }}
                      </span>
                                    </td>
                                    <td>{{ order.date }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <p v-else class="text-muted">No recent orders to display.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Chart from "chart.js/auto";
    import axios from "axios";

    export default {
        name: "SellerDashboard",
        data() {
            return {
                // Dummy data for KPIs
                kpis: [
                    { label: "Total Products", value: 45 },
                    { label: "Total Orders", value: 120 },
                    { label: "Pending Orders", value: 5 },
                    { label: "Revenue Earned", value: "$5,000" },
                    { label: "New Orders This Month", value: 15 },
                ],
                // Dummy data for recent orders
                recentOrders: [
                    {
                        customer: "John Doe",
                        product: "T-Shirt",
                        total: 25.99,
                        status: "Fulfilled",
                        date: "2025-01-01",
                    },
                    {
                        customer: "Jane Smith",
                        product: "Shoes",
                        total: 79.99,
                        status: "Pending",
                        date: "2025-01-05",
                    },
                    {
                        customer: "Alice Brown",
                        product: "Hat",
                        total: 19.99,
                        status: "Canceled",
                        date: "2025-01-03",
                    },
                ],
            };
        },
        methods: {
            renderCharts() {
                // Revenue Chart
                new Chart(document.getElementById("revenueChart"), {
                    type: "line",
                    data: {
                        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
                        datasets: [
                            {
                                label: "Revenue",
                                data: [1200, 2500, 1700, 3000],
                                borderColor: "#28a745",
                                backgroundColor: "rgba(40, 167, 69, 0.2)",
                                fill: true,
                            },
                        ],
                    },
                    options: {
                        responsive: true,
                    },
                });

                // Order Chart
                new Chart(document.getElementById("orderChart"), {
                    type: "bar",
                    data: {
                        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
                        datasets: [
                            {
                                label: "Orders",
                                data: [12, 18, 15, 22],
                                backgroundColor: "#007bff",
                            },
                        ],
                    },
                    options: {
                        responsive: true,
                    },
                });
            },
            getStatusBadge(status) {
                switch (status) {
                    case "Pending":
                        return "badge-warning";
                    case "Fulfilled":
                        return "badge-success";
                    case "Canceled":
                        return "badge-danger";
                    default:
                        return "badge-secondary";
                }
            },
        },
        mounted() {
            axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
            // Render charts with dummy data
            this.renderCharts();
        },
    };
</script>

<style scoped>
    .dashboard-title {
        font-size: 2rem;
        font-weight: bold;
    }

    .kpi-card {
        border-left: 4px solid #007bff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .kpi-value {
        font-size: 1.5rem;
        font-weight: bold;
    }

    .chart-card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .recent-orders-card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .badge-warning {
        background-color: #ffc107;
        color: #fff;
    }

    .badge-success {
        background-color: #28a745;
        color: #fff;
    }

    .badge-danger {
        background-color: #dc3545;
        color: #fff;
    }

    .badge-secondary {
        background-color: #6c757d;
        color: #fff;
    }
</style>
