// resources/js/router/index.js

import { createRouter, createWebHistory } from 'vue-router';
import Login from '../Pages/Login.vue';
import Register from '../Pages/Register.vue';
import SellerRegistration from '../Pages/SellerRegistration.vue';
import Layout from '../Pages/Layout.vue';
import AdminHome from '../Pages/AdminHome.vue';
import SellerHome from '../Pages/SellerHome.vue';

// Route guard for admin-only routes
const adminGuard = (to, from, next) => {
    const userRole = localStorage.getItem('role');
    if (userRole === 'admin') {
        next();
    } else {
        next({ name: 'login' });
    }
};

// Route guard for checking valid IDs
const idGuard = (to, from, next, routeName) => {
    const id = to.params.id;
    if (!id || isNaN(id)) {
        return next({ name: routeName });
    }
    next();
};

// Route guard for registration date check
const registrationDateGuard = (to, from, next) => {
    const currentDate = new Date();
    const today = `${currentDate.getDate().toString().padStart(2, '0')}${(currentDate.getMonth() + 1).toString().padStart(2, '0')}`;

    if (to.params.date === today) {
        next();
    } else {
        next({ name: 'login' });
    }
};

const routes = [
    {
        path: '/',
        name: 'login',
        component: Login,
    },
    {
        path: '/register-:date',
        name: 'register',
        component: Register,
        beforeEnter: registrationDateGuard
    },
    {
        path: '/seller-register',
        name: 'sellerRegister',
        component: SellerRegistration,
    },
    {
        path: '/dashboard',
        name: 'dashboard',
        component: Layout,
        meta: { requiresAuth: true },
        children: [
            {
                path: '',
                name: 'adminHome',
                component: AdminHome,
            },
            {
                path: '',
                name: 'sellerHome',
                component: SellerHome,
            },
            {
                path: '/test',
                name: 'test',
                component: () => import('../Pages/Test.vue'),
            },
            {
                path: '/products',
                name: 'products',
                component: () => import('../Pages/Products.vue'),
                children: [
                    {
                        path: ':id',
                        name: 'productDetail',
                        component: () => import('../Pages/ProductDetails.vue'),
                        beforeEnter: (to, from, next) => idGuard(to, from, next, 'products')
                    },
                ]
            },
            {
                path: '/orders',
                name: 'orders',
                component: () => import('../Pages/Orders.vue'),
                beforeEnter: adminGuard,
                children: [
                    {
                        path: ':id',
                        name: 'orderDetail',
                        component: () => import('../Pages/OrderDetails.vue'),
                        beforeEnter: (to, from, next) => idGuard(to, from, next, 'orders')
                    },
                ]
            },
            {
                path: '/sellers',
                name: 'sellers',
                component: () => import('../Pages/Sellers.vue'),
                beforeEnter: adminGuard,
                children: [
                    {
                        path: ':id',
                        name: 'sellerDetail',
                        component: () => import('../Pages/SellerDetails.vue'),
                        beforeEnter: (to, from, next) => idGuard(to, from, next, 'sellers')
                    },
                ]
            },
        ],
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

router.beforeEach((to, from, next) => {
    const isAuthenticated = localStorage.getItem('token');
    if (to.matched.some(record => record.meta.requiresAuth) && !isAuthenticated) {
        next({ name: 'login' });
    } else {
        next();
    }
});

export default router;
