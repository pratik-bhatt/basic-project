<?php

namespace App\Http\Controllers;

use App\Models\Seller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;


class AuthController extends Controller
{
    public function register(RegisterRequest $request)
    {
        $user = User::create([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),
            'role' => 'admin',
        ]);

        $token = $user->createToken('DNA')->plainTextToken;

        return response()->json(['user' => $user, 'token' => $token]);
    }

    public function registerSeller(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'phone' => 'required|string',
            'address' => 'required|string|max:500',
            'company_name' => 'required|string|max:255',
            'domain' => 'nullable|string|max:255',
            'company_address' => 'nullable|string|max:500',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        DB::beginTransaction();

        try {

            $user = User::create([
                'name' => $request->get('name'),
                'email' => $request->get('email'),
                'password' => Hash::make($request->get('password')),
                'role' => 'seller',
                'status' => 'inactive',
            ]);

            Seller::create([
                'user_id' => $user->id,
                'phone' => $request->get('phone'),
                'address' => $request->get('address'),
                'company_name' => $request->get('company_name'),
                'domain' => $request->get('domain'),
                'company_address' => $request->get('company_address'),
            ]);
            DB::commit();

            return response()->json([], 201);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'message' => 'Registration failed',
                'error' => config('app.debug') ? $e->getMessage() : 'Something went wrong.',
            ], 500);
        }
    }

    public function login(LoginRequest $request)
    {
        $credentials = $request->only('email', 'password');

        if (!Auth::attempt($credentials)) {

            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        $user = Auth::user();
        if ($user->status !== 'active') {

            return response()->json(['message' => 'Your account is inactive. Please contact support.'], 403);
        }

        return response()->json([
            'user' => $user,
            'token' => $user->createToken('DNA')->plainTextToken,
            'role' => $user->role,
        ]);
    }

    public function logout(Request $request)
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'No authenticated user found.',
            ], 401);
        }

        // Revoke current access token
        $user->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Logged out successfully.',
        ]);
    }
}
