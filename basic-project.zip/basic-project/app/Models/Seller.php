<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Seller extends Model
{
    protected $fillable = [
        'user_id',
        'phone',
        'address',
        'company_name',
        'company_address',
        'domain',
        'shopify_store_id',
        'shopify_store_url',
        'shopify_api_key',
        'shopify_api_secret',
        'shopify_access_token',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function products()
    {
        return $this->hasMany(SellerProduct::class);
    }
}
